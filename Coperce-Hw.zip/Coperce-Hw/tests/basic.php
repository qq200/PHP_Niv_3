<?php
// include '../src/Comerce/modeles/Product.php';
// include '../src/Comerce/modeles/Price.php';
include '../vendor/autoload.php';
use Comerce\Models\Product;
use Comerce\Models\Price;

$p=new Product('test product');

$p->addPhoto("https://picsum.photos/id/100/600/300");

$p->price= new Price(1000, "EUR");
// var_dump($p);
print $p;

// var_dump($p->price);
// var_dump($p->name);


?>
