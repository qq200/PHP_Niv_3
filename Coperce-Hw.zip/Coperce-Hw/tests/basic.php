<?php
// include '../src/Comerce/modeles/Product.php';
// include '../src/Comerce/modeles/Price.php';
include '../vendor/autoload.php';
use Comerce\Models\Product;
use Comerce\Models\Price;

// $p=new Product('test product');

// $p->addPhoto("https://picsum.photos/id/100/600/300");
// $p->addPhoto("https://picsum.photos/id/10/600/300");
// $p->addPhoto("https://picsum.photos/id/100/600/300");
// $p->addPhoto("https://picsum.photos/id/10/600/300");
// $p->addPhoto("https://picsum.photos/id/90/600/300");
// $p->price= new Price(1000, "EUR");
// var_dump($p->__toString());
$c=new Price ("vgdwv", "M2");

var_dump($c);
print "<br>";
var_dump($c->currency);



?>
