<?php
namespace Comerce\Models;

class Product{
    private $name;  //daca e privat trebuie prin __set
    private $photo;
    private $price;

    public function __construct($name, $photo=[],
$price=null){
    $this->names= $name;
    $this->photo= $photo;
    $this->price=$price;
    }

    //SETER & GETER (MAGIC!!!)

    public function __set($propr_name, $propr_value){
        if($propr_name=="name" ){
            if(is_string($propr_value)){
                $propr_value=trim($propr_value);  //daca de aplica proprietaea name se curata spatiile goale
            }else{
                die ("ERROR, {$propr_name} must be string");
            }
        }

        //Acasa photos de verificat is_array
        //      price -> is object de tip Price
        $this->$propr_name=$propr_value;
    }



     public function __get($propr_name){
        return $this->$propr_name;
    }

    public function addPhoto($url){

        //Acsa de verificat daca nu exista adresa url sa nu se dubleze
        //      validare la amount si currency
        
        $this->photo[]=$url;
    }
    public function __toString(){
        return "
        
        <h2>{$this->name}</h2>
        <img src=\"{$this->photo[0]}\"/>
        <p>{$this->price}</p>
        
        ";
    }
}



?>