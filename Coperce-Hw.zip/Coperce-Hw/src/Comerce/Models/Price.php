<?php
namespace Comerce\Models;

class Price{
    private $amount;  //daca e privat trebuie prin __set
    private $currency;
    
    public function __construct($amount, $currency){
    $this->amount= $amount;
    $this->currency= $currency;
    
    }

    //SETER & GETER (MAGIC!!!)

    public function __set($propr_name, $propr_value){
        
         $this->$propr_name=$propr_value;
    }



     public function __get($propr_name){
        return $this->$propr_name;
    }

    
    public function __toString(){
        return "
        <div>

        </div>
        <b>{$this->amount}</b>
        
        <span>{$this->currency}</span>
        
        ";
    }
}

