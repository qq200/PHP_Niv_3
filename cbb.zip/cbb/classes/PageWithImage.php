<?php

class PageWithImage extends Page{
    public $image;

    public function __construct(string $url, string $title,string $body, string $image){
        parent::__construct ($url, $title, $body );
        $this->image=  $image;
    }

    public function __toString(): string{
            $body=$this->body;
            $this->body=$this->body."<img src=\"{$this->image}\">";
            $html=parent::__toString();
            $this->body=$body;
            return $html;

            // return "
            // <!DOCTYPE html>
            //  <head>
            //     <meta charset=\"UTF-8\">
            //     <title>{$this->title}</title>
            // </head>
            // <body>
            //     {$this->body}
            //     <img src=\"{$this->image}\">
            // </body>
            // </html>";
    }
}

?>