<?php

class PageWithAd extends Page{
    public $baner;

    public function __construct(string $url, string $title,string $body, string $baner){
        parent::__construct ($url, $title, $body );
        $this->baner=  $baner;
    }

    public function __toString(): string{
            $body=$this->body;
            $this->body=$this->body.$this->baner;
            $html=parent::__toString();
            $this->body=$body;
            return $html;
    }
}

?>