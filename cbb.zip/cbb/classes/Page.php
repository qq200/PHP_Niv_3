<?php

class Page{
    private $url;
    public $title;
    public $body;

    public function __construct(string $url, string $title,string $body){
        $this->setUrl($url);
        $this->title= $title;
        $this->body=  $body;
    }
    public function setUrl(string $url){
        if($url !=""){
            $this->url= $url;
        }else{
            print "EROR Cannot set empty URL!";
        }
    }
    public function getUrl(){
        return $this->url;
    }

    public function __toString(): string{
            return"
            <!DOCTYPE html>
             <head>
                <meta charset=\"UTF-8\">
                <title>{$this->title}</title>
            </head>
            <body>
                {$this->body}
            </body>
            </html>";
    }
}



?>