<?php
declare(strict_types=1);
//  spread operator ...???

//*inheritance
//*parent::, referance/copy 

include 'autoload.php';
// include './classes/Page.php';

// print new Page("Test/page","TITLE", "Bla la la");
$pa=new PageWithAd("/tema1","TITLE", "Bla ADD", "Good reclama");
$ia=new PageWithImage("Test/page","TITLE", "Bla ADD", "1.jpeg");
$p=new Page("","TITLE", "Bla ADD", "Good reclama");
// print $pa;
// print $ia;
$p->setUrl("/page-new");
// $p->setUrl("");
print $p->getUrl();

?>