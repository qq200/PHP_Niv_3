<?php
//automatic class search/include
spl_autoload_register(function ($class_name){
    include_once "./classes/{$class_name}.php";
});

?>