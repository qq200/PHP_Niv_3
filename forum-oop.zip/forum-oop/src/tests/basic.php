<?php
include '../../src/models/TimeStempModel.php';
include '../../src/models/Post.php';
include '../../src/models/User.php';
include '../../src/models/Topik.php';

use forum\models\Post;
use forum\models\User;
use forum\models\Topik;
use forum\models\TimeStempModel;

$u1=new User("Vasiok", "V99", "2019-2-2", "Vas@mail.ru", []);
$p1=new Post("Greva", "Lorem bla bla bla", []);
$t1=new Topik("Politica", []);
$p1->setUser($u1);
$p1->addTopik($t1);

print"<pre>";
var_dump($p1);
// var_dump($u1);
// var_dump($t1);


// acasa comerce-oop: Prtoduct: name, fotos-array string, price-legatura cu un obiect de tip price, legatura cu mai multe comenzi
//                    Price: amount, currency
//                    Order: are legatura cu Client, items- array asociativ de Product, total_price-se leaga cu obiectul Price, statut
//                    Client: name, foto, legatura cu Order
?>