<?php
namespace forum\models;
use forum\models\TimeStempModel;

class Post extends TimeStempModel{
   public $title;
   public $content;
   public $user;
   public $topics;
   
   public function __construct($title, $content, $topic){
        parent::__construct();
        $this->title=$title;
        $this->content=$content;
        $this->topics[]=$topic;

   }

   public function setUser($user){
       $this->user=$user;
       $this->user->addPost($this);
   }
   public function addTopik($topic){
       $this->topics[]=$topic;
       $topic->addPost($this);
   }

  
}




?>