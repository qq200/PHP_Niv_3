<?php
namespace forum\models;
use forum\models\TimeStempModel;

class User extends TimeStempModel{
   public $full_name;
   public $user_name;
   public $password;
   public $mail;
   public $posts;

    public function __construct($full_name, $user_name, $password, $mail, $post){
       parent::__construct();   //apelam parent ca sa setam timpul
       $this->full_name=$full_name;
       $this->user_name= $user_name;
       $this->password= $this->secure_password();
       $this->mail= $mail;
       $this->posts[]=$post;

   }
   public function secure_password(){
        return hash("sha256", $this->password);//securizarea/codarea parolei
   }
  
   public function addPost($post){
       $this->posts[]=$post;
   }
}




?>