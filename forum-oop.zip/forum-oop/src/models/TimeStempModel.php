<?php

// pentru a transmite altor clase logica legata de timp
namespace forum\models;

class TimeStempModel{
   public $created;
   public $modified;
   public $viewed;

   public function __construct(){
       $this->created= time();
       $this->modified= 0;
       $this->viewed= 0;
   }
  
}




?>