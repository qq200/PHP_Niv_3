<?php
namespace forum\models;
use forum\models\TimeStempModel;

class Topik extends TimeStempModel{
   public $title;
   public $posts;

   public function __construct($title, $post){
        parent::__construct();
        $this->title=$title;
        $this->posts=[];
   }
   public function addPost($post){
       $this->posts[]=$post;
   }

}




?>