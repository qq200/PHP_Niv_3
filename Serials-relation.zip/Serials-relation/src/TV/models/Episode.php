<?php
namespace tv\models;

class Episode{
    public $name;
    public $duration;
    public $seasons;
    

    public function __construct(string $name){
        $this->name=$name;
        
    }
    public function setSeason($season){
        $this->seasons[]=$season;
        
    }
    public function setDuration(int $duration){
        $this->duration=$duration;
    }
    public function getDuration(){
        return $this->duration;
    }
}


?>
