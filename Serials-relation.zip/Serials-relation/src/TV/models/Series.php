<?php
namespace tv\models;

class Series{
    public $name;
    public $categories;
    public $seasons;
    public $duration;

    public function __construct(string $name){
        $this->name=$name;
        $this->categories=[];//lista de categorii
        $this->seasons =[];//lista de sezoane
    }
    
    public function addSeason(int $number, $season){
        $this->seasons[]=$season;
    }
    public function getDuration(){
        foreach ($this->seasons as $number=>$season){
            foreach ($season->episodes as $number=>$ep){
                $x+= $ep->duration;
            }
           
        }
        return $x;
        }
        
    
    public function printHTML(){
        return "




        ";
        // "Series name (2 Seasons, 6 episodes)"
        // > 1. "Season 1 name"
        // > 1. "Episode 1 Title"    [00:45]
        // > 2. "Episode 2 Title"    [00:40]
        // > 3. "Episode 3 Title"    [00:45]
        //   ....
        // > 2. "Season 2 name"
        // > 1. "Episode 1 Title"    [00:45]
        // > 2. "Episode 2 Title"    [00:40]
        // > 3. "Episode 3 Title"    [00:45] 
    
    }
    
}
?>