<?php
namespace tv\models;

class Season {
    public $name;
    public $episodes;
    public $series; 
    public $duration; 
        
    public function __construct(string $name){
            $this->name=$name;
            $this->episodes=[];
            
    }
    public function addEpisode(int $number, $episode){
        $this->episodes[]=$episode;
    }
    public function setSeries($serie){
        $this->series[]=$serie;
    }
    public function getDuration( ){
        foreach ($this->episodes as $number=>$episode){
            $x+= $episode->duration;
        }
        return $x;

    }
     
}


?>