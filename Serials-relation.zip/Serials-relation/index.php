<?php
    include 'src/TV/models/Episode.php';
    include 'src/TV/models/Season.php';
    include 'src/TV/models/Series.php';

    use TV\models\Episode; 
    use TV\models\Season;
    use TV\models\Series;
    
    $film_1=new Series("super men");
    $season_1=new Season("Introducere");
    $episod_1=new Episode("Intriga");
    $episod_2=new Episode("Dezvaluire");
    $film_1->addSeason(1, $season_1);
    $season_1->addEpisode(1, $episod_1);
    $season_1->setSeries($film_1);
    $episod_1->setSeason($season_1);
    $episod_1->setDuration(90);
    $season_1->addEpisode(2, $episod_2);
    $episod_2->setSeason($season_1);
    $episod_2->setDuration(80);


    print "<pre>";
    // var_dump($season_1);
    // var_dump($episod_1->getDuration());
    var_dump($season_1->getDuration());
    var_dump($film_1->getDuration());
    // var_dump($film_1->getDuration($season_1));
    // var_dump($season_1->episodes);
    
?>