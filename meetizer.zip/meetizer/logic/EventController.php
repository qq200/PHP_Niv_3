<?php
//aceasta clasa este o cutie care contine functii legate de evenimente
class EventController{
    //lista de evenimente
    public static function index(){
        $events=[
            [
                "title"=>"Event 1"
            ],
            [
                "title"=>"Event 2"
            ],
            [
                "title"=>"Event 3"
            ]
        ];
        render("events", ['events'=>$events]);
    }
    public static function add(){
        // $add_events=[
        //     'name'      =>'string',
        //     'start_date'=>'string',
        //     'duration'  =>'integer',
        //     'location_id'=>'integer'            
        // ];
        global $countries;
        render("event-form", [
            'countries'=>$countries,
            'error_date_past'=> get_messages("error_date_past"),
            'error_name_short'=> get_messages("error_name_short")
                
            ]); //render la pagina care trebuie incarcata
    }
    public static function save(){
        $name =$_POST['name'] ?? "";
        if(strlen($name)<3){
            // print "Name too short!";
            set_message("Name too short!", "error_name_short" ,"error");
        }
        $start_date =$_POST['start_date'] ?? "";
        if(strtotime($start_date)< time()){
            // print "Date cannot set in past";
            set_message("Date cannot set in past","error_date_past", "error");
        }

        // $new_events=[
        //     'name'      =>$_POST['name'],
        //     'start_date'=>$_POST['start_date'],
        //     'duration'  =>$_POST['duration'],
        //     'location_id'=>$_POST['location_id']            
        // ];
        header("location: ?q=/events/add");
        print "<pre>";
        var_dump($_POST);
        var_dump(get_messages("error-name-short"));
        // render("events");
        // render("events", ['new_events'=>$new_events]);
    }
}


?>