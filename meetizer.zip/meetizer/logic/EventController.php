<?php
//aceasta clasa este o cutie care contine functii legate de evenimente
class EventController{
    //lista de evenimente
    public static function index(){
        $events=[
            [
                "title"=>"Event 1"
            ],
            [
                "title"=>"Event 2"
            ],
            [
                "title"=>"Event 3"
            ]
        ];
        render("events", ['events'=>$events]);
    }
    public static function add(){
        $add_events=[
            'name'      =>'string',
            'start_date'=>'string',
            'duration'  =>'integer',
            'location_id'=>'integer'            
        ];
        render("event-form", ['add_events'=>$add_events]); //render la pagina care trebuie incarcata
    }
    public static function save(){
        $new_events=[
            'name'      =>$_POST['name'],
            'start_date'=>$_POST['start_date'],
            'duration'  =>$_POST['duration'],
            'location_id'=>$_POST['location_id']            
        ];
        
        var_dump($new_events);
        render("events", ['new_events'=>$new_events]);
    }
}


?>