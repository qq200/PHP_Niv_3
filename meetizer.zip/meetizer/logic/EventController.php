<?php
//aceasta clasa este o cutie care contine functii legate de evenimente
use Respect\Validation\Validator as v;
// $val_string=v::stringType();

class EventController{
    //lista de evenimente
    public static function index(){
        $events=[
            [
                "title"=>"Event 1"
            ],
            [
                "title"=>"Event 2"
            ],
            [
                "title"=>"Event 3"
            ]
        ];
        render("events", ['events'=>$events]);
    }
    public static function add(){
        // $add_events=[
        //     'name'      =>'string',
        //     'start_date'=>'string',
        //     'duration'  =>'integer',
        //     'location_id'=>'integer'            
        // ];
        global $countries;
        render("event-form", [
            'countries'=>$countries,
            'error_date_past'=> get_messages("error_date_past"),
            'error_name_short'=> get_messages("error_name_short")
                
            ]); //render la pagina care trebuie incarcata
    }
    public static function save(){
        $name =$_POST['name'] ?? "";
        if( v::type('string')->length(3, 19)->validate("$name") ){
            print "OK";
        }else{
            set_message("Name too short!", "error_name_short" ,"error");
            print "NO OK";
        }
        $start_date =$_POST['start_date'] ?? "";
        if(v::leapYear()->validate('2019')){
            print "year OK";
        }else{
            set_message("Date cannot set in past", "error_date_past", "error");
            print "year NO OK";
        }
        // if(strtotime($start_date)< time()){
        //     // print "Date cannot set in past";
        //     set_message("Date cannot set in past","error_date_past", "error");
        // }
        
        
        print "<pre>";
        var_dump($_POST);
        var_dump(get_messages("error_date_past"));
        // header("location: ?q=/events/add");
        // render("events");
        // render("events", ['new_events'=>$new_events]);
    }
}


?>