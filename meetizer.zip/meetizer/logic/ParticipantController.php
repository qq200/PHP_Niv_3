<?php
//aceasta clasa este o cutie care contine functii legate de participanti
class ParticipantController{
    //lista de evenimente
    public static function index(){
        render("participant");
    }
}


?>