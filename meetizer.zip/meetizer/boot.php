<?php
//bootstrapping- va starta tot ce poate fi necesar in aplicatie
include 'vendor/autoload.php';
$countries =include 'vendor/umpirsky/country-list/data/en_US/country.php';

//////TWIG INITIALIZATIONS////////////////
use \Twig\Loader\FilesystemLoader;
use \Twig\Environment;

$loader = new FilesystemLoader('./templates');

$twig = new Environment($loader, [
    'cache' => FALSE,
    'debug' =>true,
]);
/////////////////////////////////////////////
////////////////helpers INITIALIZATIONS///////
include 'helpers.php';
///////////////////////////////////////////
////////////////ROUTS INITIALIZATIONS///////
include 'routes.php';
///////////////////////////////////////////
?>