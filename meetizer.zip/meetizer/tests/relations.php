<?php
//de creat un eveniment care are loc intr-o locatie la care participa 3 paticipanti;
//extarageti evenimentul cu lista de participanti si locatie

//!!ordinea de executie https://github.com/Greg0/Lazer-Database



?>