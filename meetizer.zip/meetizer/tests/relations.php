<?php

include '../vendor/autoload.php';
include '../config.php';

define('LAZER_DATA_PATH', $config['database_path']);
use Lazer\Classes\Database as Db;
use Lazer\Classes\Relation;


$event =Db::table('events');
    $event->id=30;
    $event->name='Concres International';
    $event->start_date='2019-02-02';
    $event->duration=10;
    $event->location_id=201;
    $event->save();

$location =Db::table('locations'); 
    $location->id=201;
    $location->name='Summit';
    $location->country='Moldova';
    $location->city='Chisinau';
    $location->street='Tighina';
    $location->number='49/3 of 200';       
    $location->save();

$user=Db::table('users');
    $user->id=101;
    $user->name='Vasea Petrovici';
    $user->email='vasea@mail.ru';
    $user->password='123456ab';       
    $user->create_date='2015-05-20';
    $user->save();

    $user->id=102;
    $user->name='Ion Banan';
    $user->email='ionut@mail.com';
    $user->password='3334446ab';       
    $user->create_date='2014-07-20';
    $user->save();

    $user->id=103;
    $user->name='Gosa Tractorist';
    $user->email='gosaa@rambler.ru';
    $user->password='88888aa';       
    $user->create_date='2015-10-29';
    $user->save();

$ticket=Db::table('tickets');
//leaga participantii de evenimente!!!
    
 $ticket->id=112233;
 $ticket->event_id=30;
 $ticket->user_id=101;
 $ticket->save();

 $ticket->id=222233;
 $ticket->event_id=30;
 $ticket->user_id=102;
 $ticket->save();

 $ticket->id=332233;
 $ticket->event_id=30;
 $ticket->user_id=103;
 $ticket->save();
#######################
$event_list = $event
// ->relations('locations')
->relations('users')
// ->relations('tickets')
;
    
// foreach($event_list as $row)
// {
//     print_r($row);
// }
var_dump($event_list);






// Relation::table('events')
//         ->belongsTo('locations')
//         ->localKey('location_id')
//         ->foreignKey('id')
//         ->setRelation();
// Relation::table('tickets')
//         ->belongsTo('users')
//         ->localKey('user_id')
//         ->foreignKey('id')
//         ->setRelation();
// Relation::table('tickets')
//         ->belongsTo('events')
//         ->localKey('event_id')
//         ->foreignKey('id')
//         ->setRelation();
//de creat un eveniment care are loc intr-o locatie la care participa 3 paticipanti;
//extarageti evenimentul cu lista de participanti si locatie

//!!ordinea de executie https://github.com/Greg0/Lazer-Database



?>