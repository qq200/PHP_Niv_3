<?php
// inlantuirea->object

class Box{
    public $value;
    public function __construct($value){
        $this->value=$value;
    }
    public function x10(){
        $this->value*=100;
        return $this;
    }
    public function x100(){
        $this->value*=100;
        return $this;
    }
    public function x1000(){
        $this->value*=100;
        return $this;
    }
    public function print(){
        print"This object value is:{$this->value}";
        return $this;
    }
}

// $b=new Box(100);
// $b->x10();
// $b->x100();
// $b->x1000();
// $b->print();
// var_dump($b);

//daca nu se pune in variabila se imbraca in paranteze
(new Box(100))->x10()->x100()->x1000()->print(); //obligatoriu trebuie return in functie
// Acasa: format number sa apara 100.000.000
?>

