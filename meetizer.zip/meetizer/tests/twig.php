<?php
//testing twig engine
use \Twig\Loader\FilesystemLoader;
use \Twig\Environment;
use \Twig\Extension\DebugExtension;
use organizer\database\Event;
print "TEST STARTED <br>";

//creeam obiectul unui loader-seteaza mapa de incarcare a sabloanelor
$loader = new FilesystemLoader('./templates');

//anulam cahe
$twig = new Environment($loader, [
    'cache' => FALSE,
    'debug' =>true,
]);
$twig->addExtension(new DebugExtension());
$e1=new Event('vasea', '2019-05-05', 3, 'columna 23',[]);
$e2=new Event('petea', '2019-06-05', 1, 'columna 23',[]);
$e2->addParticipant('petrovici');
$e3=new Event('pete3', '2019-06-03', 3, 'columna 23',[]);
$e4=new Event('pete4', '2019-06-04', 4, 'columna 23',[]);
$e5=new Event('pete5', '2019-06-05', 5, 'columna 23',[]);
$e6=new Event('pet6a', '2019-06-06', 1, 'columna 23',[]);
$e7=new Event('7etea', '2019-07-05', 1, 'columna 23',[]);
$e8=new Event('pet8a', '2019-08-05', 8, 'columna 23',[]);
$e9=new Event('9etea', '2019-06-09', 1, 'columna 23',[]);
$e9->addParticipant('vova');
$e10=new Event('petea10', '2019-06-10', 1, 'columna 23',[]);
$e11=new Event('petea11', '2019-06-11', 1, 'columna 23',[]);
$e12=new Event('petea12', '2019-06-12', 1, 'columna 23',[]);
print $twig->render('pages/events.html.twig', [
    'data'=>array(
        $e1, $e2,$e3,$e4,$e5,$e6,$e7,$e8,$e9,$e10,$e11,$e12
    )
    
]);


print "TEST Ended <br>";

//generati o lista de 15 events, transmiteti arrai (lista) in sablon, afisati lista

?>