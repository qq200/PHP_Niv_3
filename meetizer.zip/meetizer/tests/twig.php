<?php
//testing twig engine
use \Twig\Loader\FilesystemLoader;
use \Twig\Environment;
use \Twig\Extension\DebugExtension;
print "TEST STARTED <br>";

//creeam obiectul unui loader-seteaza mapa de incarcare a sabloanelor
$loader = new FilesystemLoader('./templates');

//anulam cahe
$twig = new Environment($loader, [
    'cache' => FALSE,
    'debug' =>true,
]);
$twig->addExtension(new DebugExtension());

print $twig->render('pages/events.html.twig', [
    'data'=>[
        'money'=>1000,
        'currency'=>'usd',
        'list'=>[
            'one'=> 100,
            'two'=> 200,
            'three'=>300
        ]
    ]
]);
print "TEST Ended <br>";

//generati o lista de 15 events, transmiteti arrai (lista) in sablon, afisati lista

?>