<?php
    include '../database/Ticket.php';
    include '../database/Participant.php';
    include '../database/Event.php';

    use organizer\database\Participant; 
    use organizer\database\Ticket;
    use organizer\database\Event;

    $p1=new Participant("Vasea", "V@mail.com", "2019-8-2", "123456");

    $e1=new Event("Congres", "2019-9-12", 3, "Tighina 22", [],[]);
    $e2=new Event("Festival", "2019-8-27", 2, "Asachi 3", [],[]);


    $t1=new Ticket();
    $t1->setParticipant($p1);
    $t2=new Ticket();
    $t2->setParticipant($p1);

    $t1->setEvent($e1);
    $t2->setEvent($e2);
    print "<pre>";
    var_dump($t1);
    // var_dump($t2);
?>