<?php
//1- clasa cutie cu instrumente
    //utilizam clasa direct fara Obiecte
//2- clasa sablon pentru obiecte
    //$obj->property
class Box{
    public static $value=10;
    public static function f(){}
}

Box::$value;
Box::f();

?>