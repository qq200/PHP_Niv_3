<?php
//inregistram si citim events in BD
include '../vendor/autoload.php';
include '../config.php';
define('LAZER_DATA_PATH', $config['database_path']);

use Lazer\Classes\Database as Db;


$event =Db::table('events');
// $event->name='First Name';
// $event->start_date='2019-01-01';
// $event->duration=100;
// $event->save();

// $event->name='First Name';
// $event->start_date='2019-01-01';
// $event->duration=100;
// $event->save();

// $event->name='Lest Name 2';
// $event->start_date='2019-03-02';
// $event->duration=50;
// $event->save();

// $event->name='Best Name';
// $event->start_date='2019-03-03';
// $event->duration=20;
// $event->save();
#######################
//obtinem toate inregistrarile
// $event_list =$event->findAll()->asArray();
$event_list =$event
                // ->where('start_date', '>=', '2019-03-02')
                // ->orderBy('start_date', 'DESC')
                // ->findAll()
                        ->find(1)
                        ->delete();
                // ->asArray();
var_dump($event_list);

?>