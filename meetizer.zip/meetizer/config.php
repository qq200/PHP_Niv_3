<?php
//configurarea aplicatiei

$config=[
    'database_path' => realpath(__DIR__).'/data/'
]

?>