<?php
//functii ajutatoare


function render($template, $data=[]){
    global $twig;
    print $twig->render("pages/$template.html.twig",$data);

}



?>