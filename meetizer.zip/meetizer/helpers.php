<?php
//functii ajutatoare


function render($template, $data=[]){
    global $twig;
    print $twig->render("pages/$template.html.twig",$data);

}

//functia care poate inregistra mesaje in sessiune
//status poate fi: succes, warning, error, notice...
function set_message($message, $context, $status='succes'){
    if(session_status()!==PHP_SESSION_ACTIVE){
    session_start();
    $_SESSION['message'][$context]=[$status=>$message];
    }
}

function get_messages($context,$status=''){

    if(session_status()!==PHP_SESSION_ACTIVE){
    session_start();
    }
    $mes=$_SESSION['message'][$context]?? [];
    unset($_SESSION['message'][$context]);
    return $mes;
}

function has_message($context, $status=''){
    if(session_status()!==PHP_SESSION_ACTIVE){
    session_start();
    }
    return isset($_SESSION['message'][$context]);
}
//acasa: functie care singura verifica si starteaza sesiunea
?>