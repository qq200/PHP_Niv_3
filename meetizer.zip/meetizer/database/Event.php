<?php
namespace organizer\database;


class Event{
    public $name;
    public $start_data;
    public $durations;
    public $address;
    public $participants;

    public function __construct(string $name, string $start_data, int $durations, string $address, array $participants){
        $this->name      = $name;
        $this->start_data= $start_data;
        $this->durations = $durations;
        $this->address   = $address;
    }
    public function addParticipant( $participant){
        $this->participants[]=$participant;
    }

    

}



?>