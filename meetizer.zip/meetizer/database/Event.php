<?php
namespace organizer\database;


class Event{
    //name, start_data(string), durations(int), address (string, participantii (array)



    //constructor care seteaza totul in afara de participanti
    //addParticipant-metoda care adauga 1 participant
    

}



?>