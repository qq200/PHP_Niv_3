<?php
namespace organizer\database;

class Location{

}



?>