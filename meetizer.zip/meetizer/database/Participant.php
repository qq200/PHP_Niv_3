<?php
namespace organizer\database;

class Participant{
    public $name;
    public $mail;
    public $created;
    public $password;
    public $tickets;


    public function __construct(string $name, string $mail, string $created, string $password){
        $this->name    = $name;
        $this->mail    = $mail;
        $this->created = $created;
        $this->password= $password;
        $this->tickets =[]; //lista de tichete
        
    }

    public function addTicket($ticket){
         $this->tickets[]=$ticket;
    }
    
}



?>