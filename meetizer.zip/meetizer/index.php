<?php
include 'vendor/autoload.php';

include 'tests/twig.php';

?>