<?php

include 'boot.php';


//dynamic routing
    //domain/?q=/home
    //domain/?q=/about
?>