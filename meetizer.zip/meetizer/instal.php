<?php
// acest fisier ruleaza o data cind lansam aplicatia
include 'config.php';
include 'vendor/autoload.php';
define('LAZER_DATA_PATH', $config['database_path']);


//PREGATESTE baza de date

//1-creaza tabelul 'events'
use Lazer\Classes\Database as Db;
use Lazer\Classes\Relation; 

Db::create('events', //denumire tabel
//schema (cimpurile tabelului)
    [
        'id'        =>'integer',
        'name'      =>'string',
        'start_date'=>'string',
        'duration'  =>'integer',
        'location_id'=>'integer' //legatura cu o locatie
       
    ]
);




Db::create('locations', //denumire tabel
//schema (cimpurile tabelului)
    [
        'id'        =>'integer',
        'name'      =>'string',
        'country'   =>'string',
        'city'      =>'string',
        'street'    =>'string',
        'number'    =>'string'       
    ]
);
Db::create('users', //denumire tabel
//schema (cimpurile tabelului)
    [
        'id'        =>'integer',
        'name'      =>'string',
        'email'     =>'string',
        'password'  =>'string',       
        'create_date'=>'string',
    ]
);
Db::create('tickets', //denumire tabel
//schema (cimpurile tabelului)
//leaga participantii de evenimente!!!
    [
        'id'        =>'integer',
        'event_id'  =>'integer',
        'user_id'    =>'integer'
        
    ]
);
Relation::table('events')
        ->belongsTo('locations')
        ->localKey('location_id')
        ->foreignKey('id')
        ->setRelation();
Relation::table('tickets')
        ->belongsTo('users')
        ->localKey('user_id')
        ->foreignKey('id')
        ->setRelation();
Relation::table('tickets')
        ->belongsTo('events')
        ->localKey('event_id')
        ->foreignKey('id')
        ->setRelation();
// Acasa: relations.php
?>