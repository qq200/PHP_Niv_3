<?php
//logica de rutare=de prelucrare adrese
//domain.ext/?q=/some/path

$path= $_GET['q'] ?? "/"; //sau pagina radacina


//caile din sistem
$routes=[
    '/'=>'home',
    '/events'=>'EventController@index',
    '/participants'=>'ParticipantController@index',
    '/tickets'=>'tickets',
];

//daca exista calea indicata in array
if(array_key_exists($path, $routes)){
    list($controller, $method)=explode('@',$routes[$path]);
    // var_dump($routes[$path]);
    // var_dump($controller);
    // var_dump($method);
    include "logic/$controller.php";
    $controller::$method();
}else{
    render("404");
}
var_dump($path);


?>