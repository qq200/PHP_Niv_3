<?php
include 'fb/User.php';
include 'ok/User.php';
// VARIANTA 1

$u1=new social\fb\User();
$u2=new social\ok\User();
var_dump($u1);
var_dump($u2);

// VARIANTA 2
use social\fb\User as FbUser;
use social\ok\User as OkUser;
$u=new FbUser();
var_dump($u);
$u=new OkUser();
var_dump($u);
?>