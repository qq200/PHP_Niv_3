<?php
namespace social\fb;
class User {
    public $fullname= "Some user";
    public $platform= "Facebook";
}

?>