<?php
namespace social\ok;
class User {
    public $fullname= "Some user";
    public $platform= "Odnoklassniki";
}

?>