<?php
    // класс сообщения в системе
    class Message{
            public $text;
            public $created;
            public $viewed;
            public $from;
            public $to;
            

            public function __construct(string $text, $from, $to){
                
                $this->text=$text;
                $this->created=time();
                $this->viewed=time();
                $this->from=$from;
                $this->to=$to;

            }
            public function __toString(){
                return json_encode($this) ;
            }
            public function toHTML(){
                
                return "
                    <div>
                    <p>{$this->text}</p>
                    <small>created - from:{$this->from->username}</small>
                    </div>
                    <hr>";
            }
            // 1) добавьте свойства
            // + text (string), created (string), viewed (string), from (User), to (User)
            // created - время когда сообщение было отправленно 
            // viewed - время когда сообщение было просмотренно 
            // 2) конструктор должен уточнять типы входных параметров !!! -> php strict typing
            // 3) когда контсруктор выполняется - считается что в этот помент было отправленно сообщение - time()
            // +__construct()

            
            //  4) этот метод должен вернуть
            //     представление сообщения в таком формате
            /*
                <div>
                    <p>text</p>
                    <small>created - from(username)</small>
                </div>
            */
            // +__toString()
    }

?>