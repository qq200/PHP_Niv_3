
<pre>
<?php
include 'User.php';
include 'Message.php';


$c1=new User("marry77", "mar7@test.mail", "mar123", ["administrator"]);
$c2=new User("john88", "joh8@test.mail", "joh123", []);

var_dump($c1->toHTML());
var_dump($c2->toHTML());
// var_dump ($c1);
// var_dump ($c2);
// print $c2;
$m1=new Message("bla bla bla Text test",$c2, $c1);
var_dump($m1->toHTML());
// var_dump($m1);

////////////////////////////////////////////////////////////////////////////////////////////////////
 // 1) подключить необходимые библиотеки
 // 2) создать первого пользователя ("marry77", "mar7@test.mail", "mar123", ["administrator"])
 // 3) создать второго пользователя ("john88", "joh8@test.mail", "joh123", [])
 // 4) выслать сообщение ("Hello!") от имени второго - первому
 // 5) выслать сообщение ("Hi!") от имени первого - второму

 // * проверку делайте print / var_dump
?>
</pre>

