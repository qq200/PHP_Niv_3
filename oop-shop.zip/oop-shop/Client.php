<?php
class Client{
    public $id;
    public $username;
    public $avatar;
    public $email;
    public $password;

    public function __construct($username,$avatar,$email,$password){
        $this->id=rand();
        $this->username=$username;
        $this->avatar= $avatar;
        $this->email=$email;
        $this->password=$password;
    }
    public function __toString(){
        return json_encode($this) ;
    }
    public function toHTML(){
        return "
            <div>
                <h2> {$this->username}</h2>
                <p>{$this->email}<br>{$this->password}</p>
            </div>
        " ;
    }
}


?>