<pre>
<?php
include 'Product.php';
include 'Client.php';
include 'Cart.php';
// $p1=new Product("iphone X2", "phone whaoo", "1.jpg", 10);
// $p2=new Product("iphone X2", "GOOD", "2.jpg", 30);
$client1=new Client("Vovan","av.img","vv@mail.com", "1245");
$cart1= new Cart($client1);
// $cart2= new Cart($client2);
$cart1->addProduct(new Product("iphone X2", "phone whaoo", "1.jpg", 10));
$cart1->addProduct(new Product("iphone X2", "GOOD", "2.jpg", 30));

// var_dump($p1);
// var_dump($p2);
// print $p1->toHTML();
// print $p2;
var_dump ($cart1->toHTML());
var_dump ($cart1->total_cost);
var_dump ($cart1);

// packagist.org
?>
</pre>