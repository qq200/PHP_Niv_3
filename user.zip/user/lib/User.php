<?php
    class User{
        private $username;
        private $email;
        private $password;
        private $avatar;

        public function __construct(string $url, string $title,string $body){
            $this->setUrl($url);
            $this->title= $title;
            $this->body=  $body;
        }
        public function setUsername(string $username){
            if(count($username) >= 5 and preg_match("[a-z0-9]", $username) == 1){
                $this->username= $username;
            }else{
                print "EROR Cannot set USERNAME! Need 5 simbols [a-z0-9]";
            }            
        }
        public function setEmail(string $email){
            if((preg_match("@", $email) == 1) and (preg_match(".", $email) == 1)){
                $this->email= $email;
            }else{
                print "EROR Cannot set EMAIL! Need simbols: [@ and .]";
            }            
        }
        public function setPassword(string $password){
            if(count($password) >= 6 ){
                $this->password= $password;
            }else{
                print "EROR Cannot set Password! Need 6 simbols";
            }            
        }
        public function setUsername(string $avatar){
            $avatar_acces = explode(".", $avatar);
            if (($avatar_acces[1] != "png") and ($avatar_acces[1] != "jpeg") and ($avatar_acces[1] != "jpg")) {
                print "EROR Cannot set AVATAR! Need PNG/JPG/JPEG";
            }else{
                $this->avatar= $avatar;
            }            
        }
        public function getUsername(){
            return $this->username;
        }
        public function getEmail(){
            return $this->email;
        }
        public function getPassword(){
            return $this->password;
        }
        public function getAvatar(){
            return $this->avatar;
        }

        public function __toString(): string{
                return"
                <!DOCTYPE html>
                <head>
                    <meta charset=\"UTF-8\">
                    <title>{$this->title}</title>
                </head>
                <body>
                    {$this->body}
                </body>
                </html>";
        }
        // добавить в класс 4 приватных свойств:
            // username, email, password, avatar
        // и два магических метода:
            // __construct(),__toString()

        // добавить setters/getters для всех свойств класса
            // сеттерами применить валидацию:
                // username - минимум 5 символов
                //          - можно использовать только a..z0..9_
                
                // email    - должен содержать "@" и "." в указаном порядке

                // password - минимум 6 символов

                // avatar   - только адресса каринок с  PNG/JPG/JPEG

        // добавить мето save() который сохраняет как JSON текущий обьект
        // в папку "database" имя файла соответствует "time()" когда сохраняется 
        // файл

        // при сохранении пользователя - его аватар (если назначен) копируется
        // в папку "avatars"

        // добавить load( $filename ) который загружает значения свойств из
        // указанного JSON файла

    }
?>